public class lab1ex1 {
    public static void main(String[] args) {
        int a = 9;
        int b = 20;
        int c = 10;
        int d = 4;
        int e = 8;
        int f = 96;
        int g = 9;
        int h = 30;
        int i = 1;
        int j = 15;

        int sum = a + b + c + d + e + f + g + h + i + j;
        System.out.println("Сума чисел: " + sum);

        int rizn = a - b - c - d - e - f - g - h - i - j;
        System.out.println("Різниця чисел: " + rizn);

        int dob = a * b * c * d * e * f * g * h * i * j;
        System.out.println("Добуток чисел: " + dob);

        int chastk = a / b / c / d / e / f / g / h / i / j;
        System.out.println("Частка чисел: " + chastk);
    }
    
}
