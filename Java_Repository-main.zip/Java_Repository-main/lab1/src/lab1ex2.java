

public class lab1ex2 {
    public static void main(String[] args) {
        
        String word1 = "Мене";
        String word2 = "звати";
        String word3 = "Олександр,";
        String word4 = "я";
        String word5 = "люблю";
        String word6 = "пити";
        String word7 = "чай";
        String word8 = "та";
        String word9 = "подорожувати";
        String word10 = "Україною";

        System.out.println(word1 + " " + word2 + " " + word3 + " " + word4 + " " + word5 + " " + word6 + " " + word7 + " " + word8 + " " + word9 + " " + word10);
    }
}