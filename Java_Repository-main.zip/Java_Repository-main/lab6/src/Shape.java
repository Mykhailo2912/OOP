public class Shape {
    
    protected double volume;

    public Shape(double volume) {
        this.volume = volume;
    }

    public Shape() {}

    public double getVolume () {
        return volume;
    }
}