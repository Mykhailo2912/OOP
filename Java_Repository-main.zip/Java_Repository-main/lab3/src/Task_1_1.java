public class Task_1_1 {

    public void ForCycle(){

        int i = 0;
        System.out.println("Task 1_1:\n");
        for(i = 0; i <= 50; i++){
            System.out.println(i + " Це повiдомлення виведеться 50 разiв");
        }
    }
}