public class Task_1_2 {

    public void WhileCycle(){
        
        int i = 0;
        System.out.println("Task 1_2:\n");
        while(i <= 50){
            System.out.println(i + " Це повiдомлення також виведеться 50 разiв");
            i++;
        }
    }
}