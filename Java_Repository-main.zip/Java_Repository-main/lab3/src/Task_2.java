public class Task_2 {

    public void ForHoursCycle(){

        System.out.println("Task 2:\n");
        for (int hour = 0; hour <= 2; hour++) {
            for (int minute = 0; minute < 60; minute++) {
                System.out.println(hour + " h " + minute + " min");
            }
        }
    }
}